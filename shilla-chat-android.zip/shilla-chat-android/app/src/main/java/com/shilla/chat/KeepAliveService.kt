package com.shilla.chat

import android.Manifest
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder

/** خدمة بتفضل شغالة في الخلفية عشان الاتصال بالأصحاب والرسائل ما يقطعوش لما الشاشة تقفل. */
class KeepAliveService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        Hub.init(this)
        Notif.ensureChannels(this)
        val n = Notif.foreground(this)
        if (Build.VERSION.SDK_INT >= 29) {
            var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE
            if (Build.VERSION.SDK_INT >= 30 &&
                checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            ) {
                type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            }
            startForeground(1, n, type)
        } else {
            startForeground(1, n)
        }
        Hub.start()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Hub.start()
        return START_STICKY
    }

    override fun onDestroy() {
        Hub.stop()
        super.onDestroy()
    }
}
