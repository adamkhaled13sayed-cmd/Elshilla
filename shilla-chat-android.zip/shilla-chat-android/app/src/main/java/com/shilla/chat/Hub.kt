package com.shilla.chat

import android.content.Context
import android.content.SharedPreferences
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.Vibrator
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.AdvertisingOptions
import com.google.android.gms.nearby.connection.ConnectionInfo
import com.google.android.gms.nearby.connection.ConnectionLifecycleCallback
import com.google.android.gms.nearby.connection.ConnectionResolution
import com.google.android.gms.nearby.connection.ConnectionsClient
import com.google.android.gms.nearby.connection.ConnectionsStatusCodes
import com.google.android.gms.nearby.connection.DiscoveredEndpointInfo
import com.google.android.gms.nearby.connection.DiscoveryOptions
import com.google.android.gms.nearby.connection.EndpointDiscoveryCallback
import com.google.android.gms.nearby.connection.Payload
import com.google.android.gms.nearby.connection.PayloadCallback
import com.google.android.gms.nearby.connection.PayloadTransferUpdate
import com.google.android.gms.nearby.connection.Strategy
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import java.util.UUID

/**
 * قلب التطبيق: بيدوّر على أصحابك ويتوصل بيهم مباشرة (بلوتوث/واي فاي مباشر عن طريق Nearby)،
 * وبيبعت الرسائل بطريقة "فيضان" (كل جهاز بيعيد توجيه الرسالة للي جنبه) فالرسالة بتوصل
 * حتى لو صاحبك مش في مدى مباشر منك لكن في مدى واحد من أصحابكم التانيين.
 *
 * كل الدوال بتتنادى على الـ main thread (Nearby بيرجّع الـ callbacks عليه).
 */
object Hub {
    interface Listener {
        fun onChange()
        fun onNewMessage(m: Msg)
        fun onToast(s: String)
    }

    enum class Phase { NONE, OUTGOING, INCOMING, ACTIVE }

    private const val SERVICE_ID = "com.shilla.chat.v1"
    private const val SYNC_WINDOW_MS = 24L * 3600 * 1000
    private const val SYNC_MAX = 60
    private const val ONLINE_MS = 30_000L
    private const val ID_ALERT_MSG = 10
    private const val ID_ALERT_CALL = 11

    private lateinit var app: Context
    private lateinit var prefs: SharedPreferences
    private val main = Handler(Looper.getMainLooper())
    private val listeners = ArrayList<Listener>()

    var myId = ""; private set
    var myName = ""; private set
    private var roomHash = ""

    var started = false; private set
    var uiVisible = false
    var error = ""; private set

    /** كل الأصحاب اللي اتعرفنا عليهم (uid -> اسم). */
    val users = LinkedHashMap<String, String>()
    private val lastSeen = HashMap<String, Long>()
    private val direct = HashMap<String, String>()         // uid -> endpointId (متوصلين مباشرة)
    private val endpointUid = HashMap<String, String>()    // endpointId -> uid
    private val pending = HashMap<String, Long>()          // uid -> وقت بدء محاولة الاتصال

    val messages = ArrayList<Msg>()
    private val seen = HashSet<String>()

    // ---- المكالمات ----
    var callPhase = Phase.NONE; private set
    var callPeer: String? = null; private set
    var callStartTs = 0L; private set
    private var ringtone: Ringtone? = null

    private var tick = 0

    // ============ تهيئة وبيانات ============
    fun init(ctx: Context) {
        if (::app.isInitialized) return
        app = ctx.applicationContext
        prefs = app.getSharedPreferences("shilla", Context.MODE_PRIVATE)
        var id = prefs.getString("uid", null)
        if (id == null) {
            id = UUID.randomUUID().toString().replace("-", "").take(10)
            prefs.edit().putString("uid", id).apply()
        }
        myId = id
        myName = prefs.getString("name", "") ?: ""
        roomHash = hash(prefs.getString("room", "") ?: "")
        loadUsers()
        loadMessages()
    }

    fun hasProfile(): Boolean = myName.isNotBlank() && (prefs.getString("room", "") ?: "").isNotBlank()
    fun savedName(): String = myName
    fun savedRoom(): String = prefs.getString("room", "") ?: ""

    fun saveProfile(name: String, room: String) {
        prefs.edit().putString("name", name.trim().take(20)).putString("room", room.trim()).apply()
        myName = name.trim().take(20)
        roomHash = hash(room)
        if (started) {
            stop()
            start()
        }
    }

    private fun hash(room: String): String =
        MessageDigest.getInstance("SHA-256")
            .digest(room.trim().lowercase().toByteArray())
            .joinToString("") { "%02x".format(it) }
            .take(8)

    private fun loadUsers() {
        try {
            val j = JSONObject(prefs.getString("users", "{}") ?: "{}")
            val it = j.keys()
            while (it.hasNext()) {
                val k = it.next()
                users[k] = j.getString(k)
            }
        } catch (_: Exception) {
        }
    }

    private fun saveUsers() {
        prefs.edit().putString("users", JSONObject(users as Map<*, *>).toString()).apply()
    }

    private fun remember(uid: String, name: String) {
        if (uid == myId || uid.isEmpty()) return
        if (users[uid] != name) {
            users[uid] = name
            saveUsers()
        }
    }

    private fun msgFile() = File(app.filesDir, "messages.jsonl")

    private fun loadMessages() {
        try {
            val f = msgFile()
            if (!f.exists()) return
            val all = f.readLines()
            val lines = all.takeLast(1000)
            for (l in lines) {
                try {
                    val m = Msg.fromJson(JSONObject(l))
                    if (seen.add(m.id)) messages.add(m)
                } catch (_: Exception) {
                }
            }
            if (all.size > 1000) f.writeText(lines.joinToString("\n") + "\n")
        } catch (_: Exception) {
        }
    }

    private fun appendMsg(m: Msg) {
        try {
            msgFile().appendText(m.toJson().toString() + "\n")
        } catch (_: Exception) {
        }
    }

    // ============ مستمعين للواجهة ============
    fun addListener(l: Listener) { if (!listeners.contains(l)) listeners.add(l) }
    fun removeListener(l: Listener) { listeners.remove(l) }
    private fun changed() { listeners.toList().forEach { it.onChange() } }
    private fun toast(s: String) { listeners.toList().forEach { it.onToast(s) } }

    // ============ حالة ============
    fun isOnline(uid: String): Boolean =
        direct.containsKey(uid) || (System.currentTimeMillis() - (lastSeen[uid] ?: 0L) < ONLINE_MS)

    fun isDirect(uid: String): Boolean = direct.containsKey(uid)

    fun statusLine(): String = when {
        error.isNotEmpty() -> error
        !started -> "اضغط هنا لتشغيل الاتصال (لازم توافق على الصلاحيات)"
        direct.isEmpty() -> "بدور على أصحابك… (خليهم يفتحوا التطبيق ويشغّلوا البلوتوث)"
        else -> "متصل مباشرة بـ ${direct.size} من أصحابك"
    }

    // ============ تشغيل / إيقاف ============
    private fun client(): ConnectionsClient = Nearby.getConnectionsClient(app)
    private fun advName(): String = "$roomHash|$myId|${myName.take(20)}"

    fun start() {
        if (started || !hasProfile()) return
        started = true
        error = ""
        val c = client()
        c.startAdvertising(
            advName(), SERVICE_ID, lifecycle,
            AdvertisingOptions.Builder().setStrategy(Strategy.P2P_CLUSTER).build()
        ).addOnFailureListener { fail(it) }
        startDiscovery()
        main.removeCallbacks(ticker)
        main.postDelayed(ticker, 3000)
        changed()
    }

    fun stop() {
        started = false
        main.removeCallbacks(ticker)
        if (callPhase != Phase.NONE) endCall("", notifyPeer = true)
        try {
            val c = client()
            c.stopAdvertising()
            c.stopDiscovery()
            c.stopAllEndpoints()
        } catch (_: Exception) {
        }
        direct.clear(); endpointUid.clear(); pending.clear()
        changed()
    }

    private fun startDiscovery() {
        client().startDiscovery(
            SERVICE_ID, discovery,
            DiscoveryOptions.Builder().setStrategy(Strategy.P2P_CLUSTER).build()
        ).addOnFailureListener { fail(it) }
    }

    private fun restartDiscovery() {
        if (!started) return
        try { client().stopDiscovery() } catch (_: Exception) {}
        startDiscovery()
    }

    private fun fail(e: Exception) {
        val code = (e as? ApiException)?.statusCode
        if (code == ConnectionsStatusCodes.STATUS_ALREADY_ADVERTISING ||
            code == ConnectionsStatusCodes.STATUS_ALREADY_DISCOVERING
        ) return
        error = when (code) {
            17 -> "خدمات Google Play مش متاحة على التليفون ده"
            else -> "مشكلة في الاتصال المباشر (كود $code). اتأكد من البلوتوث والصلاحيات (والموقع لو الأندرويد قديم)."
        }
        changed()
    }

    private val ticker = object : Runnable {
        override fun run() {
            if (!started) return
            tick++
            flood(
                JSONObject().put("t", "pres").put("u", myId).put("n", myName).put("ttl", 3),
                null
            )
            if (tick % 6 == 0) restartDiscovery()
            changed()
            main.postDelayed(this, 10_000)
        }
    }

    // ============ اكتشاف واتصال ============
    private fun parseName(n: String): Triple<String, String, String>? {
        val p = n.split("|", limit = 3)
        return if (p.size == 3) Triple(p[0], p[1], p[2]) else null
    }

    private fun request(endpointId: String, uid: String) {
        val now = System.currentTimeMillis()
        if (direct.containsKey(uid)) return
        if (now - (pending[uid] ?: 0L) < 15_000) return
        pending[uid] = now
        client().requestConnection(advName(), endpointId, lifecycle)
            .addOnFailureListener { pending.remove(uid) }
    }

    private val discovery = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(endpointId: String, info: DiscoveredEndpointInfo) {
            val (room, uid, name) = parseName(info.endpointName) ?: return
            if (room != roomHash || uid == myId) return
            remember(uid, name)
            endpointUid[endpointId] = uid
            if (direct.containsKey(uid)) return
            if (myId < uid) {
                request(endpointId, uid)
            } else {
                // الطرف التاني هو اللي المفروض يبدأ. لو ماحصلش، نبدأ إحنا بعد شوية.
                main.postDelayed({
                    if (started && !direct.containsKey(uid)) request(endpointId, uid)
                }, 6000)
            }
            changed()
        }

        override fun onEndpointLost(endpointId: String) {}
    }

    private val lifecycle = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(endpointId: String, info: ConnectionInfo) {
            val parsed = parseName(info.endpointName)
            if (parsed == null || parsed.first != roomHash) {
                client().rejectConnection(endpointId)
                return
            }
            endpointUid[endpointId] = parsed.second
            remember(parsed.second, parsed.third)
            pending[parsed.second] = System.currentTimeMillis()
            client().acceptConnection(endpointId, payloads)
        }

        override fun onConnectionResult(endpointId: String, result: ConnectionResolution) {
            val uid = endpointUid[endpointId] ?: return
            pending.remove(uid)
            if (result.status.statusCode == ConnectionsStatusCodes.STATUS_OK) {
                val old = direct[uid]
                direct[uid] = endpointId
                if (old != null && old != endpointId) {
                    try { client().disconnectFromEndpoint(old) } catch (_: Exception) {}
                }
                lastSeen[uid] = System.currentTimeMillis()
                sendJson(endpointId, JSONObject().put("t", "hello").put("u", myId).put("n", myName))
                syncTo(endpointId, uid)
                changed()
            } else {
                endpointUid.remove(endpointId)
            }
        }

        override fun onDisconnected(endpointId: String) {
            val uid = endpointUid.remove(endpointId) ?: return
            if (direct[uid] == endpointId) direct.remove(uid)
            if (!direct.containsKey(uid) && callPeer == uid && callPhase != Phase.NONE) {
                endCall("المكالمة انقطعت", notifyPeer = false)
            }
            changed()
            main.postDelayed({ restartDiscovery() }, 2000)
        }
    }

    // ============ استقبال ============
    private val payloads = object : PayloadCallback() {
        override fun onPayloadReceived(endpointId: String, payload: Payload) {
            val b = payload.asBytes() ?: return
            if (b.isEmpty()) return
            val uid = endpointUid[endpointId] ?: return
            lastSeen[uid] = System.currentTimeMillis()
            if (b[0] == 1.toByte()) {
                if (callPhase == Phase.ACTIVE && callPeer == uid) CallAudio.onRemoteFrame(b)
                return
            }
            try {
                handle(endpointId, uid, JSONObject(String(b, 1, b.size - 1, Charsets.UTF_8)))
            } catch (_: Exception) {
            }
        }

        override fun onPayloadTransferUpdate(endpointId: String, update: PayloadTransferUpdate) {}
    }

    private fun handle(from: String, uid: String, j: JSONObject) {
        when (j.optString("t")) {
            "hello" -> remember(j.optString("u", uid), j.optString("n", "؟"))
            "msg" -> receiveMsg(Msg.fromJson(j), from, sync = j.has("sy"))
            "pres" -> {
                val u = j.optString("u")
                if (u.isEmpty() || u == myId) return
                lastSeen[u] = System.currentTimeMillis()
                remember(u, j.optString("n", "؟"))
                val ttl = j.optInt("ttl", 0)
                if (ttl > 0) flood(j.put("ttl", ttl - 1), from)
                changed()
            }
            "call" -> handleCall(uid, j.optString("a"))
        }
    }

    private fun receiveMsg(m: Msg, from: String, sync: Boolean) {
        if (m.from == myId) return
        if (!seen.add(m.id)) return
        remember(m.from, m.fromName)
        val forMe = m.to == "all" || m.to == myId
        if (forMe) {
            messages.add(m)
            appendMsg(m)
            listeners.toList().forEach { it.onNewMessage(m) }
            val fresh = System.currentTimeMillis() - m.ts < 60_000
            if (!uiVisible && fresh) {
                val title = if (m.to == "all") "${m.fromName} (الشلة)" else m.fromName
                Notif.alert(app, ID_ALERT_MSG, title, m.text)
            }
            changed()
        }
        if (!sync) flood(m.toJson(), from) // نعيد التوجيه للي جنبنا
    }

    // ============ إرسال ============
    private fun frame(j: JSONObject): ByteArray {
        val body = j.toString().toByteArray(Charsets.UTF_8)
        val out = ByteArray(body.size + 1)
        out[0] = 0
        System.arraycopy(body, 0, out, 1, body.size)
        return out
    }

    private fun send(endpointId: String, bytes: ByteArray) {
        try {
            client().sendPayload(endpointId, Payload.fromBytes(bytes))
        } catch (_: Exception) {
        }
    }

    private fun sendJson(endpointId: String, j: JSONObject) = send(endpointId, frame(j))

    private fun flood(j: JSONObject, except: String?) {
        val bytes = frame(j)
        for (ep in direct.values.toList()) if (ep != except) send(ep, bytes)
    }

    fun sendMessage(text: String, to: String) {
        val t = text.trim().take(2000)
        if (t.isEmpty()) return
        val m = Msg(UUID.randomUUID().toString().replace("-", "").take(12), myId, myName, to, t, System.currentTimeMillis())
        seen.add(m.id)
        messages.add(m)
        appendMsg(m)
        flood(m.toJson(), null)
        changed()
    }

    /** لما صاحبنا يتوصل، نبعتله الرسائل اللي فاتته (آخر 24 ساعة). */
    private fun syncTo(endpointId: String, uid: String) {
        val since = System.currentTimeMillis() - SYNC_WINDOW_MS
        val list = messages.filter { it.ts > since && (it.to == "all" || (it.to == uid && it.from == myId)) }
            .takeLast(SYNC_MAX)
        for (m in list) sendJson(endpointId, m.toJson().put("sy", 1))
    }

    // ============ المكالمات ============
    fun canCall(uid: String): Boolean = callPhase == Phase.NONE && direct.containsKey(uid)

    fun startCall(uid: String) {
        val ep = direct[uid]
        if (callPhase != Phase.NONE) return
        if (ep == null) {
            toast("لازم يكون في اتصال مباشر مع ${users[uid] ?: "صاحبك"} الأول (قرّبوا من بعض)")
            return
        }
        callPeer = uid
        callPhase = Phase.OUTGOING
        sendJson(ep, JSONObject().put("t", "call").put("a", "invite"))
        changed()
    }

    fun acceptCall() {
        val uid = callPeer ?: return
        val ep = direct[uid] ?: return
        if (callPhase != Phase.INCOMING) return
        ringStop()
        Notif.cancel(app, ID_ALERT_CALL)
        sendJson(ep, JSONObject().put("t", "call").put("a", "accept"))
        beginAudio()
    }

    fun rejectOrHangup() {
        val uid = callPeer
        val ep = if (uid != null) direct[uid] else null
        if (ep != null) {
            val a = if (callPhase == Phase.INCOMING) "reject" else "end"
            sendJson(ep, JSONObject().put("t", "call").put("a", a))
        }
        endCall("", notifyPeer = false)
    }

    private fun handleCall(uid: String, a: String) {
        when (a) {
            "invite" -> {
                val ep = direct[uid]
                if (callPhase != Phase.NONE || ep == null) {
                    if (ep != null) sendJson(ep, JSONObject().put("t", "call").put("a", "busy"))
                    return
                }
                callPeer = uid
                callPhase = Phase.INCOMING
                ringStart()
                if (!uiVisible) {
                    Notif.alert(app, ID_ALERT_CALL, "📞 ${users[uid] ?: "صاحبك"} بيتصل بيك", "اضغط للرد")
                }
                changed()
            }
            "accept" -> if (callPhase == Phase.OUTGOING && callPeer == uid) beginAudio()
            "reject" -> if (callPeer == uid) endCall("${users[uid] ?: "صاحبك"} رفض المكالمة", false)
            "busy" -> if (callPeer == uid) endCall("${users[uid] ?: "صاحبك"} في مكالمة تانية", false)
            "end" -> if (callPeer == uid) endCall("المكالمة انتهت", false)
        }
    }

    private fun beginAudio() {
        val ok = CallAudio.start(app) { frame ->
            main.post {
                val ep = callPeer?.let { direct[it] }
                if (ep != null && callPhase == Phase.ACTIVE) send(ep, frame)
            }
        }
        if (!ok) {
            toast("مقدرتش أشغّل الميكروفون. اتأكد إنك وافقت على صلاحية الميكروفون.")
            rejectOrHangup()
            return
        }
        callPhase = Phase.ACTIVE
        callStartTs = System.currentTimeMillis()
        changed()
    }

    private fun endCall(note: String, notifyPeer: Boolean) {
        if (notifyPeer) {
            val ep = callPeer?.let { direct[it] }
            if (ep != null) sendJson(ep, JSONObject().put("t", "call").put("a", "end"))
        }
        ringStop()
        Notif.cancel(app, ID_ALERT_CALL)
        CallAudio.stop()
        callPhase = Phase.NONE
        callPeer = null
        if (note.isNotEmpty()) toast(note)
        changed()
    }

    fun setMuted(m: Boolean) { CallAudio.muted = m }
    fun setSpeaker(on: Boolean) = CallAudio.setSpeaker(on)

    @Suppress("DEPRECATION")
    private fun ringStart() {
        try {
            val r = RingtoneManager.getRingtone(app, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE))
            if (Build.VERSION.SDK_INT >= 28) r.isLooping = true
            r.play()
            ringtone = r
            (app.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator).vibrate(longArrayOf(0, 600, 600), 0)
        } catch (_: Exception) {
        }
    }

    @Suppress("DEPRECATION")
    private fun ringStop() {
        try { ringtone?.stop() } catch (_: Exception) {}
        ringtone = null
        try { (app.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator).cancel() } catch (_: Exception) {}
    }
}
