package com.shilla.chat

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build

object Notif {
    const val CH_FG = "fg"
    const val CH_MSG = "msg"

    fun ensureChannels(c: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(
                NotificationChannel(CH_FG, "التطبيق شغال", NotificationManager.IMPORTANCE_LOW)
            )
            nm.createNotificationChannel(
                NotificationChannel(CH_MSG, "الرسائل والمكالمات", NotificationManager.IMPORTANCE_HIGH)
            )
        }
    }

    @Suppress("DEPRECATION")
    private fun builder(c: Context, ch: String): Notification.Builder =
        if (Build.VERSION.SDK_INT >= 26) Notification.Builder(c, ch) else Notification.Builder(c)

    private fun openApp(c: Context): PendingIntent {
        val i = Intent(c, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
        return PendingIntent.getActivity(c, 0, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    fun foreground(c: Context): Notification =
        builder(c, CH_FG)
            .setSmallIcon(android.R.drawable.stat_notify_chat)
            .setContentTitle("شلة شات شغال")
            .setContentText("بدور على أصحابك القريبين منك")
            .setContentIntent(openApp(c))
            .setOngoing(true)
            .build()

    @Suppress("DEPRECATION")
    fun alert(c: Context, id: Int, title: String, text: String) {
        try {
            val n = builder(c, CH_MSG)
                .setSmallIcon(android.R.drawable.stat_notify_chat)
                .setContentTitle(title)
                .setContentText(text)
                .setContentIntent(openApp(c))
                .setAutoCancel(true)
                .setPriority(Notification.PRIORITY_HIGH)
                .setDefaults(Notification.DEFAULT_ALL)
                .build()
            (c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(id, n)
        } catch (_: Exception) {
        }
    }

    fun cancel(c: Context, id: Int) {
        try {
            (c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(id)
        } catch (_: Exception) {
        }
    }
}
