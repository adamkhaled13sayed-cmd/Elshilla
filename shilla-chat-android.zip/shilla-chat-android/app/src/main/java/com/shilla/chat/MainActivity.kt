package com.shilla.chat

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Vibrator
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity(), Hub.Listener {

    private val cBg = Color.parseColor("#0B1418")
    private val cPanel = Color.parseColor("#14232A")
    private val cLine = Color.parseColor("#22363F")
    private val cText = Color.parseColor("#E8F1F2")
    private val cMuted = Color.parseColor("#8AA3AB")
    private val cBrand = Color.parseColor("#14B8A6")
    private val cBrandDark = Color.parseColor("#0F766E")
    private val cThem = Color.parseColor("#1C2F38")
    private val cRed = Color.parseColor("#EF4444")
    private val cGreen = Color.parseColor("#22C55E")

    private val ui = Handler(Looper.getMainLooper())

    private lateinit var root: FrameLayout
    private lateinit var setupView: View
    private lateinit var mainView: View
    private lateinit var callView: View

    private lateinit var nameEt: EditText
    private lateinit var roomEt: EditText

    private lateinit var statusTv: TextView
    private lateinit var chipsBox: LinearLayout
    private lateinit var threadTv: TextView
    private lateinit var callBtn: Button
    private lateinit var listView: ListView
    private lateinit var input: EditText

    private lateinit var callAvatar: TextView
    private lateinit var callName: TextView
    private lateinit var callState: TextView
    private lateinit var acceptBtn: Button
    private lateinit var muteBtn: Button
    private lateinit var speakerBtn: Button

    private var current = "all"
    private val unread = HashMap<String, Int>()
    private var shown: List<Msg> = emptyList()
    private var prevCount = -1
    private var prevThread = ""
    private var muted = false
    private var speaker = false
    private val timeFmt = SimpleDateFormat("hh:mm a", Locale("ar"))

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radiusDp: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radiusDp).toFloat()
        }

    private fun label(text: String, sizeSp: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = text
            textSize = sizeSp
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun button(text: String, bg: Int, fg: Int, onClick: () -> Unit): Button =
        Button(this).apply {
            this.text = text
            setTextColor(fg)
            isAllCaps = false
            background = rounded(bg, 24)
            setPadding(dp(18), 0, dp(18), 0)
            setOnClickListener { onClick() }
        }

    private fun field(hint: String): EditText =
        EditText(this).apply {
            this.hint = hint
            setHintTextColor(cMuted)
            setTextColor(cText)
            textSize = 17f
            gravity = Gravity.CENTER
            background = rounded(cPanel, 14)
            setPadding(dp(14), dp(14), dp(14), dp(14))
            maxLines = 1
            inputType = InputType.TYPE_CLASS_TEXT
        }

    // ============================================================ إنشاء الواجهة
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Hub.init(applicationContext)
        Notif.ensureChannels(this)
        window.statusBarColor = cBg
        window.navigationBarColor = cBg

        root = FrameLayout(this).apply {
            setBackgroundColor(cBg)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        setupView = buildSetup()
        mainView = buildMain()
        callView = buildCall()
        root.addView(setupView, FrameLayout.LayoutParams(-1, -1))
        root.addView(mainView, FrameLayout.LayoutParams(-1, -1))
        root.addView(callView, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)

        if (Hub.hasProfile()) {
            showMain()
            ensureReady()
        } else {
            showSetup()
        }
    }

    private fun buildSetup(): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(28), dp(28), dp(28), dp(28))
        }
        box.addView(label("💬 شلة شات", 30f, cText, true))
        box.addView(
            label(
                "دردشة ومكالمات مع أصحابك بدون إنترنت ولا شبكة ولا هوتسبوت — مباشرة من تليفون لتليفون.\n\n" +
                    "اكتب اسمك، واتفقوا كلكم على نفس \"كلمة سر الشلة\".",
                15f, cMuted
            ).apply { gravity = Gravity.CENTER; setPadding(0, dp(10), 0, dp(20)) }
        )
        nameEt = field("اسمك")
        roomEt = field("كلمة سر الشلة (نفسها عند كل أصحابك)")
        box.addView(nameEt, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
        box.addView(roomEt, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(18) })
        box.addView(
            button("ابدأ", cBrand, Color.parseColor("#032B27")) {
                val n = nameEt.text.toString().trim()
                val r = roomEt.text.toString().trim()
                if (n.isEmpty() || r.isEmpty()) {
                    Toast.makeText(this, "اكتب الاسم وكلمة السر", Toast.LENGTH_SHORT).show()
                } else {
                    Hub.saveProfile(n, r)
                    showMain()
                    ensureReady()
                }
            },
            LinearLayout.LayoutParams(-1, dp(52))
        )
        return box
    }

    private fun buildMain(): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        // الشريط العلوي
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(cPanel)
            setPadding(dp(14), dp(10), dp(10), dp(10))
        }
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titles.addView(label("شلة شات", 18f, cText, true))
        statusTv = label("", 12f, cMuted).apply { setOnClickListener { ensureReady() } }
        titles.addView(statusTv)
        header.addView(titles, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(label("⚙", 22f, cText).apply {
            setPadding(dp(12), dp(6), dp(12), dp(6))
            setOnClickListener {
                nameEt.setText(Hub.savedName())
                roomEt.setText(Hub.savedRoom())
                showSetup()
            }
        })
        header.addView(label("⏻", 22f, cRed).apply {
            setPadding(dp(12), dp(6), dp(12), dp(6))
            setOnClickListener {
                stopService(Intent(this@MainActivity, KeepAliveService::class.java))
                Hub.stop()
                finish()
            }
        })
        col.addView(header, LinearLayout.LayoutParams(-1, -2))

        // الأصحاب
        chipsBox = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        val hs = HorizontalScrollView(this).apply {
            setBackgroundColor(cPanel)
            isHorizontalScrollBarEnabled = false
            addView(chipsBox)
        }
        col.addView(hs, LinearLayout.LayoutParams(-1, -2))

        // عنوان المحادثة + زر الاتصال
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(6), dp(14), dp(6))
        }
        threadTv = label("", 16f, cText, true)
        bar.addView(threadTv, LinearLayout.LayoutParams(0, -2, 1f))
        callBtn = button("📞 اتصال", cGreen, Color.parseColor("#052E16")) {
            if (current != "all") Hub.startCall(current)
        }
        bar.addView(callBtn, LinearLayout.LayoutParams(-2, dp(40)))
        col.addView(bar, LinearLayout.LayoutParams(-1, dp(52)))

        // الرسائل
        listView = ListView(this).apply {
            divider = null
            dividerHeight = 0
            setBackgroundColor(Color.TRANSPARENT)
            adapter = this@MainActivity.adapter
        }
        col.addView(listView, LinearLayout.LayoutParams(-1, 0, 1f))

        // الإدخال
        val inputRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(cPanel)
            setPadding(dp(10), dp(8), dp(10), dp(8))
        }
        input = EditText(this).apply {
            hint = "اكتب رسالة…"
            setHintTextColor(cMuted)
            setTextColor(cText)
            textSize = 16f
            background = rounded(cBg, 22)
            setPadding(dp(16), dp(10), dp(16), dp(10))
            maxLines = 4
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            imeOptions = EditorInfo.IME_ACTION_SEND
        }
        inputRow.addView(input, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(8) })
        inputRow.addView(
            button("إرسال", cBrand, Color.parseColor("#032B27")) { sendCurrent() },
            LinearLayout.LayoutParams(-2, dp(44))
        )
        col.addView(inputRow, LinearLayout.LayoutParams(-1, -2))
        return col
    }

    private fun buildCall(): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#F0061F1B"))
            setPadding(dp(24), dp(24), dp(24), dp(24))
            isClickable = true // يمنع اللمس من النفاذ للشاشة اللي تحته
            visibility = View.GONE
        }
        callAvatar = label("؟", 48f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            background = rounded(cBrandDark, 60)
        }
        box.addView(callAvatar, LinearLayout.LayoutParams(dp(120), dp(120)))
        callName = label("", 26f, cText, true).apply { setPadding(0, dp(16), 0, dp(4)) }
        box.addView(callName)
        callState = label("", 16f, cMuted)
        box.addView(callState)

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(28), 0, 0)
        }
        acceptBtn = button("📞", cGreen, Color.WHITE) { Hub.acceptCall() }
        muteBtn = button("🎤", Color.parseColor("#334155"), Color.WHITE) {
            muted = !muted
            Hub.setMuted(muted)
            muteBtn.text = if (muted) "🔇" else "🎤"
        }
        speakerBtn = button("📱", Color.parseColor("#334155"), Color.WHITE) {
            speaker = !speaker
            Hub.setSpeaker(speaker)
            speakerBtn.text = if (speaker) "🔊" else "📱"
        }
        val hang = button("✖", cRed, Color.WHITE) { Hub.rejectOrHangup() }
        for (b in listOf(acceptBtn, muteBtn, speakerBtn, hang)) {
            row.addView(b, LinearLayout.LayoutParams(dp(68), dp(68)).apply {
                marginStart = dp(8); marginEnd = dp(8)
            })
        }
        box.addView(row)
        return box
    }

    private fun showSetup() {
        setupView.visibility = View.VISIBLE
        mainView.visibility = View.GONE
    }

    private fun showMain() {
        setupView.visibility = View.GONE
        mainView.visibility = View.VISIBLE
        refresh()
    }

    // ============================================================ الرسائل
    private fun threadOf(m: Msg): String =
        if (m.to == "all") "all" else if (m.from == Hub.myId) m.to else m.from

    private val adapter = object : BaseAdapter() {
        override fun getCount(): Int = shown.size
        override fun getItem(position: Int): Any = shown[position]
        override fun getItemId(position: Int): Long = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val m = shown[position]
            val mine = m.from == Hub.myId
            val row = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = if (mine) Gravity.START else Gravity.END
                setPadding(dp(10), dp(3), dp(10), dp(3))
            }
            val bubble = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                background = rounded(if (mine) cBrandDark else cThem, 16)
                setPadding(dp(12), dp(8), dp(12), dp(6))
            }
            val maxW = resources.displayMetrics.widthPixels * 78 / 100
            if (current == "all" && !mine) {
                bubble.addView(label(m.fromName, 12f, cBrand, true))
            }
            bubble.addView(label(m.text, 16f, Color.WHITE).apply { maxWidth = maxW })
            bubble.addView(
                label(timeFmt.format(Date(m.ts)), 11f, Color.parseColor("#B0FFFFFF")).apply {
                    gravity = Gravity.END
                }
            )
            row.addView(bubble)
            return row
        }
    }

    private fun sendCurrent() {
        val t = input.text.toString().trim()
        if (t.isEmpty()) return
        input.setText("")
        Hub.sendMessage(t, current)
    }

    // ============================================================ تحديث الواجهة
    private fun refresh() {
        if (!Hub.hasProfile() || !::statusTv.isInitialized) return
        statusTv.text = Hub.statusLine()
        buildChips()

        val uidName = Hub.users[current]
        threadTv.text = if (current == "all") "مجموعة الشلة"
        else (uidName ?: "؟") + if (Hub.isOnline(current)) " • قريب منك" else " • بعيد"
        callBtn.visibility = if (current == "all") View.GONE else View.VISIBLE
        callBtn.isEnabled = current != "all" && Hub.canCall(current)
        callBtn.alpha = if (callBtn.isEnabled) 1f else 0.4f

        shown = Hub.messages.filter { threadOf(it) == current }.sortedBy { it.ts }
        adapter.notifyDataSetChanged()
        if (shown.size != prevCount || current != prevThread) {
            listView.setSelection(adapter.count - 1)
            prevCount = shown.size
            prevThread = current
        }
        refreshCall()
    }

    private fun buildChips() {
        chipsBox.removeAllViews()
        addChip("all", "👥 الكل")
        for ((uid, name) in Hub.users) {
            addChip(uid, (if (Hub.isOnline(uid)) "🟢 " else "⚪ ") + name)
        }
    }

    private fun addChip(key: String, text: String) {
        val n = unread[key] ?: 0
        val tv = label(if (n > 0) "$text ($n)" else text, 15f, cText).apply {
            background = rounded(if (current == key) cBrandDark else cThem, 20)
            setPadding(dp(14), dp(8), dp(14), dp(8))
            setOnClickListener {
                current = key
                unread[key] = 0
                refresh()
            }
        }
        chipsBox.addView(tv, LinearLayout.LayoutParams(-2, -2).apply { marginEnd = dp(8) })
    }

    private val callTick = object : Runnable {
        override fun run() {
            if (Hub.callPhase == Hub.Phase.ACTIVE) {
                refreshCall()
                ui.postDelayed(this, 1000)
            }
        }
    }

    private fun refreshCall() {
        val ph = Hub.callPhase
        if (ph == Hub.Phase.NONE) {
            callView.visibility = View.GONE
            muted = false; speaker = false
            muteBtn.text = "🎤"; speakerBtn.text = "📱"
            return
        }
        callView.visibility = View.VISIBLE
        val name = Hub.users[Hub.callPeer ?: ""] ?: "؟"
        callName.text = name
        callAvatar.text = name.take(1)
        acceptBtn.visibility = if (ph == Hub.Phase.INCOMING) View.VISIBLE else View.GONE
        muteBtn.visibility = if (ph == Hub.Phase.ACTIVE) View.VISIBLE else View.GONE
        speakerBtn.visibility = if (ph == Hub.Phase.ACTIVE) View.VISIBLE else View.GONE
        callState.text = when (ph) {
            Hub.Phase.OUTGOING -> "بيرن…"
            Hub.Phase.INCOMING -> "بيتصل بيك…"
            else -> {
                val s = ((System.currentTimeMillis() - Hub.callStartTs) / 1000).toInt()
                "%02d:%02d".format(s / 60, s % 60)
            }
        }
        if (ph == Hub.Phase.ACTIVE) {
            ui.removeCallbacks(callTick)
            ui.postDelayed(callTick, 1000)
        }
    }

    // ============================================================ Hub.Listener
    override fun onChange() = refresh()

    override fun onNewMessage(m: Msg) {
        if (m.from == Hub.myId) return
        val t = threadOf(m)
        if (t != current) unread[t] = (unread[t] ?: 0) + 1
        val fresh = System.currentTimeMillis() - m.ts < 60_000
        if (fresh) beep()
    }

    override fun onToast(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    }

    @Suppress("DEPRECATION")
    private fun beep() {
        try {
            val tg = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 80)
            tg.startTone(ToneGenerator.TONE_PROP_BEEP, 150)
            ui.postDelayed({ tg.release() }, 500)
            (getSystemService(Context.VIBRATOR_SERVICE) as Vibrator).vibrate(120)
        } catch (_: Exception) {
        }
    }

    // ============================================================ دورة الحياة
    override fun onStart() {
        super.onStart()
        Hub.uiVisible = true
        Hub.addListener(this)
        refresh()
    }

    override fun onStop() {
        Hub.uiVisible = false
        Hub.removeListener(this)
        super.onStop()
    }

    // ============================================================ الصلاحيات
    private fun neededPerms(): List<String> {
        val l = ArrayList<String>()
        if (Build.VERSION.SDK_INT <= 31) {
            l.add(Manifest.permission.ACCESS_FINE_LOCATION)
            if (Build.VERSION.SDK_INT <= 28) l.add(Manifest.permission.ACCESS_COARSE_LOCATION)
        }
        if (Build.VERSION.SDK_INT >= 31) {
            l.add(Manifest.permission.BLUETOOTH_ADVERTISE)
            l.add(Manifest.permission.BLUETOOTH_CONNECT)
            l.add(Manifest.permission.BLUETOOTH_SCAN)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            l.add(Manifest.permission.NEARBY_WIFI_DEVICES)
            l.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        l.add(Manifest.permission.RECORD_AUDIO)
        return l
    }

    private fun granted(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun ensureReady() {
        if (!Hub.hasProfile()) return
        val missing = neededPerms().filter { !granted(it) }
        if (missing.isEmpty()) startHub() else requestPermissions(missing.toTypedArray(), 42)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        val core = neededPerms().filter {
            it != Manifest.permission.RECORD_AUDIO && it != Manifest.permission.POST_NOTIFICATIONS
        }
        if (core.all { granted(it) }) {
            startHub()
            if (!granted(Manifest.permission.RECORD_AUDIO)) {
                Toast.makeText(this, "من غير صلاحية الميكروفون المكالمات مش هتشتغل", Toast.LENGTH_LONG).show()
            }
        } else {
            Toast.makeText(
                this,
                "لازم توافق على صلاحيات البلوتوث/الأجهزة القريبة. افتح إعدادات التطبيق وفعّلها.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun startHub() {
        val i = Intent(this, KeepAliveService::class.java)
        try {
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        } catch (e: Exception) {
            Toast.makeText(this, "مقدرتش أشغّل الخدمة: ${e.message}", Toast.LENGTH_LONG).show()
        }
        ui.postDelayed({ refresh() }, 800)
    }
}
