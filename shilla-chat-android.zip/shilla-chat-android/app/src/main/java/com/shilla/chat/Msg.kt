package com.shilla.chat

import org.json.JSONObject

/** رسالة دردشة. to = "all" للمجموعة أو معرّف الشخص للرسائل الخاصة. */
data class Msg(
    val id: String,
    val from: String,
    val fromName: String,
    val to: String,
    val text: String,
    val ts: Long
) {
    fun toJson(): JSONObject = JSONObject()
        .put("t", "msg")
        .put("id", id)
        .put("from", from)
        .put("fn", fromName)
        .put("to", to)
        .put("x", text)
        .put("ts", ts)

    companion object {
        fun fromJson(j: JSONObject): Msg = Msg(
            j.getString("id"),
            j.getString("from"),
            j.optString("fn", "؟"),
            j.getString("to"),
            j.getString("x"),
            j.getLong("ts")
        )
    }
}
