package com.shilla.chat

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

/**
 * محرك الصوت للمكالمات: تسجيل 8kHz → ضغط μ-law (64 kbps) → إرسال عبر Nearby.
 * الإطار المرسل: [1][بيانات μ-law ...] — البايت الأول 1 معناه "صوت".
 */
object CallAudio {
    private const val RATE = 8000
    private const val FRAME_MS = 60
    private const val FRAME_SAMPLES = RATE * FRAME_MS / 1000 // 480

    @Volatile private var running = false
    @Volatile var muted = false

    private var rec: AudioRecord? = null
    private var track: AudioTrack? = null
    private var am: AudioManager? = null
    private val queue = LinkedBlockingQueue<ByteArray>()

    @SuppressLint("MissingPermission")
    fun start(ctx: Context, send: (ByteArray) -> Unit): Boolean {
        if (running) return true
        try {
            val audio = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am = audio
            audio.mode = AudioManager.MODE_IN_COMMUNICATION
            audio.isSpeakerphoneOn = false

            val minRec = AudioRecord.getMinBufferSize(
                RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            val r = AudioRecord(
                MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                maxOf(minRec, FRAME_SAMPLES * 2 * 4)
            )
            if (r.state != AudioRecord.STATE_INITIALIZED) {
                r.release()
                return false
            }

            val minPlay = AudioTrack.getMinBufferSize(
                RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            val t = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(RATE)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(maxOf(minPlay, FRAME_SAMPLES * 2 * 8))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()

            rec = r
            track = t
            queue.clear()
            muted = false
            running = true
            r.startRecording()
            t.play()

            Thread {
                val pcm = ShortArray(FRAME_SAMPLES)
                try {
                    while (running) {
                        var off = 0
                        while (off < FRAME_SAMPLES && running) {
                            val n = r.read(pcm, off, FRAME_SAMPLES - off)
                            if (n <= 0) break
                            off += n
                        }
                        if (off < FRAME_SAMPLES) {
                            if (!running) break
                            Thread.sleep(10)
                            continue
                        }
                        if (muted) continue
                        val out = ByteArray(1 + FRAME_SAMPLES)
                        out[0] = 1
                        for (i in 0 until FRAME_SAMPLES) out[1 + i] = linearToUlaw(pcm[i])
                        send(out)
                    }
                } catch (_: Exception) {
                }
            }.apply { name = "call-record"; start() }

            Thread {
                try {
                    while (running) {
                        val f = queue.poll(200, TimeUnit.MILLISECONDS) ?: continue
                        val n = f.size - 1
                        if (n <= 0) continue
                        val s = ShortArray(n) { ulawToLinear(f[1 + it]) }
                        t.write(s, 0, n)
                    }
                } catch (_: Exception) {
                }
            }.apply { name = "call-play"; start() }
            return true
        } catch (e: Exception) {
            stop()
            return false
        }
    }

    /** إطار صوت وصل من الطرف التاني. */
    fun onRemoteFrame(frame: ByteArray) {
        if (!running) return
        queue.offer(frame)
        while (queue.size > 10) queue.poll() // لو في تأخير، نشيل الأقدم عشان الصوت ما يتأخرش
    }

    fun setSpeaker(on: Boolean) {
        try { am?.isSpeakerphoneOn = on } catch (_: Exception) {}
    }

    fun stop() {
        running = false
        try { rec?.stop() } catch (_: Exception) {}
        try { rec?.release() } catch (_: Exception) {}
        try { track?.stop() } catch (_: Exception) {}
        try { track?.release() } catch (_: Exception) {}
        rec = null
        track = null
        queue.clear()
        try {
            am?.isSpeakerphoneOn = false
            am?.mode = AudioManager.MODE_NORMAL
        } catch (_: Exception) {}
        am = null
    }

    // ---- G.711 μ-law ----
    private fun linearToUlaw(sample: Short): Byte {
        val bias = 0x84
        val clip = 32635
        var s = sample.toInt()
        val sign = if (s < 0) { s = -s; 0x80 } else 0
        if (s > clip) s = clip
        s += bias
        var exp = 7
        var mask = 0x4000
        while (exp > 0 && (s and mask) == 0) {
            exp--
            mask = mask shr 1
        }
        val mant = (s shr (exp + 3)) and 0x0F
        return (sign or (exp shl 4) or mant).inv().toByte()
    }

    private fun ulawToLinear(b: Byte): Short {
        val u = b.toInt().inv() and 0xFF
        val sign = u and 0x80
        val exp = (u shr 4) and 0x07
        val mant = u and 0x0F
        var s = ((mant shl 3) + 0x84) shl exp
        s -= 0x84
        return (if (sign != 0) -s else s).toShort()
    }
}
