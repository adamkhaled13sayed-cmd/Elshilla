plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.shilla.chat"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.shilla.chat"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    lint { abortOnError = false }
}

dependencies {
    // Google Nearby Connections: بلوتوث + واي فاي مباشر بين التليفونات بدون أي شبكة
    implementation("com.google.android.gms:play-services-nearby:19.3.0")
}
